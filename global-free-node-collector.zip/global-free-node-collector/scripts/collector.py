#!/usr/bin/env python3
"""Collect public proxy subscription feeds, validate endpoints, and export formats.

Supported input:
- Clash YAML (proxies: [...])
- sing-box JSON (outbounds: [...])
- URI subscription lines: ss://, vmess://, vless://, trojan://, hysteria2://, hy2://, tuic://
- Base64-wrapped URI subscription text

Safety:
- Only fetch URLs explicitly listed in sources/sources.txt.
- Do not add private feeds or credentials to a public repository.
- Endpoint checks are limited to DNS + TCP connection attempts to parsed host/port.
"""
from __future__ import annotations

import base64
import binascii
import json
import os
import re
import socket
import time
import hashlib
from pathlib import Path
from urllib.parse import urlsplit, unquote, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import yaml

ROOT = Path(__file__).resolve().parents[1]
SOURCES_FILE = ROOT / "sources" / "sources.txt"
OUT = ROOT / "output"
TIMEOUT = float(os.getenv("CONNECT_TIMEOUT", "4"))
MAX_BYTES = int(os.getenv("MAX_FEED_BYTES", str(5 * 1024 * 1024)))
WORKERS = int(os.getenv("CHECK_WORKERS", "40"))
UA = "GlobalPublicFeedCollector/1.0 (+public-feed-format-validation)"

SUPPORTED = {"ss", "vmess", "vless", "trojan", "hysteria2", "hy2", "tuic"}

def read_sources():
    if not SOURCES_FILE.exists():
        return []
    result = []
    for raw in SOURCES_FILE.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line and not line.startswith("#") and line.startswith(("https://", "http://")):
            result.append(line)
    return list(dict.fromkeys(result))

def fetch_source(url):
    try:
        r = requests.get(url, timeout=15, headers={"User-Agent": UA}, stream=True,
                         allow_redirects=True)
        r.raise_for_status()
        chunks, size = [], 0
        for chunk in r.iter_content(65536):
            if not chunk:
                continue
            size += len(chunk)
            if size > MAX_BYTES:
                raise ValueError("feed exceeds MAX_FEED_BYTES")
            chunks.append(chunk)
        return url, b"".join(chunks).decode("utf-8-sig", errors="replace"), None
    except Exception as e:
        return url, "", str(e)[:240]

def b64decode_text(s):
    s = re.sub(r"\s+", "", s)
    if not s:
        return None
    s += "=" * ((4 - len(s) % 4) % 4)
    for fn in (base64.urlsafe_b64decode, base64.b64decode):
        try:
            raw = fn(s.encode())
            text = raw.decode("utf-8-sig")
            if any(x in text.lower() for x in ("vmess://", "vless://", "ss://", "trojan://", "proxies:", "outbounds")):
                return text
        except Exception:
            pass
    return None

def normalize_node(n, source):
    if not isinstance(n, dict):
        return None
    typ = str(n.get("type", "")).lower()
    if typ in ("shadowsocks",):
        typ = "ss"
    if typ in ("hysteria2",):
        typ = "hysteria2"
    if typ not in SUPPORTED:
        return None
    server = n.get("server") or n.get("address")
    port = n.get("server_port") or n.get("port")
    try:
        port = int(port)
    except Exception:
        return None
    if not server or not (1 <= port <= 65535):
        return None
    node = dict(n)
    node["type"] = typ
    node["server"] = str(server).strip("[]")
    node["server_port"] = port
    node["name"] = str(node.get("name") or node.get("tag") or f"{typ}-{server}-{port}")[:100]
    node["_source"] = source
    return node

def parse_clash(text, source):
    try:
        data = yaml.safe_load(text)
    except Exception:
        return []
    if not isinstance(data, dict) or not isinstance(data.get("proxies"), list):
        return []
    out = []
    for p in data["proxies"]:
        node = normalize_node(p, source)
        if node:
            # retain Clash options for export, with internal metadata removed later
            out.append(node)
    return out

def parse_singbox(text, source):
    try:
        data = json.loads(text)
    except Exception:
        return []
    if not isinstance(data, dict) or not isinstance(data.get("outbounds"), list):
        return []
    out = []
    for p in data["outbounds"]:
        node = normalize_node(p, source)
        if node:
            out.append(node)
    return out

def parse_vmess(uri, source):
    payload = uri[len("vmess://"):].split("#", 1)[0]
    try:
        decoded = base64.urlsafe_b64decode(payload + "=" * ((4-len(payload)%4)%4)).decode()
        d = json.loads(decoded)
        node = {
            "name": unquote(uri.split("#",1)[1]) if "#" in uri else d.get("ps", "vmess"),
            "type": "vmess", "server": d.get("add"), "server_port": int(d.get("port")),
            "uuid": d.get("id"), "alter_id": int(d.get("aid", 0) or 0),
            "cipher": "auto", "tls": str(d.get("tls","")).lower() == "tls",
            "network": d.get("net","tcp"), "_source": source
        }
        if d.get("host"): node["ws-opts"] = {"headers": {"Host": d["host"]}}
        if d.get("path"): node.setdefault("ws-opts", {})["path"] = d["path"]
        node = normalize_node(node, source)
        if node: node["_raw_uri"] = uri
        return node
    except Exception:
        return None

def parse_uri(uri, source):
    uri = uri.strip()
    scheme = uri.split(":", 1)[0].lower()
    if scheme not in SUPPORTED:
        return None
    if scheme == "vmess":
        return parse_vmess(uri, source)
    try:
        # ss://method:password@host:port or base64(method:password@host:port)
        if scheme == "ss":
            body = uri[5:].split("#",1)[0].split("?",1)[0]
            decoded = b64decode_text(body)
            candidate = decoded if decoded and "://" not in decoded else body
            if "@" not in candidate:
                candidate = base64.urlsafe_b64decode(candidate + "="*((4-len(candidate)%4)%4)).decode()
            creds, endpoint = candidate.rsplit("@",1)
            if ":" not in creds:
                creds = base64.urlsafe_b64decode(creds + "="*((4-len(creds)%4)%4)).decode()
            method, password = creds.split(":",1)
            u = urlsplit("ss://" + endpoint)
            node = {"name": unquote(uri.split("#",1)[1]) if "#" in uri else "ss",
                    "type":"ss","server":u.hostname,"server_port":u.port,
                    "cipher":method,"password":password,"_source":source}
            return normalize_node(node, source)
        u = urlsplit(uri)
        q = parse_qs(u.query)
        name = unquote(uri.split("#",1)[1]) if "#" in uri else scheme
        node = {"name":name, "type":"hysteria2" if scheme=="hy2" else scheme,
                "server":u.hostname, "server_port":u.port, "_source":source}
        if scheme in ("vless","trojan","hysteria2","hy2","tuic"):
            node["password"] = unquote(u.username or "")
            if scheme == "vless":
                node["uuid"] = unquote(u.username or "")
            if scheme == "tuic":
                node["uuid"] = unquote(u.username or "")
                node["password"] = unquote(u.password or "")
            if q.get("security", [""])[0] in ("tls","reality") or q.get("sni"):
                node["tls"] = {"enabled": True, "server_name": q.get("sni", q.get("peer", [""]))[0]}
            if q.get("type", [""])[0]:
                node["network"] = q["type"][0]
            if q.get("flow"):
                node["flow"] = q["flow"][0]
        node = normalize_node(node, source)
        if node: node["_raw_uri"] = uri
        return node
    except Exception:
        return None

def parse_feed(text, source):
    text = text.strip()
    if not text:
        return []
    # Try native structured formats first.
    nodes = parse_clash(text, source)
    if nodes:
        return nodes
    nodes = parse_singbox(text, source)
    if nodes:
        return nodes
    decoded = b64decode_text(text)
    if decoded:
        text = decoded
        nodes = parse_clash(text, source) or parse_singbox(text, source)
        if nodes:
            return nodes
    out = []
    for line in text.splitlines():
        line = line.strip().strip('"').strip("'")
        if "://" in line:
            n = parse_uri(line, source)
            if n:
                out.append(n)
    return out

def node_key(n):
    fields = [n.get("type"), n.get("server"), n.get("server_port"),
              n.get("uuid"), n.get("password"), n.get("cipher")]
    return hashlib.sha256("|".join(map(str, fields)).encode()).hexdigest()

def check_endpoint(node):
    host, port = node["server"], int(node["server_port"])
    start = time.time()
    try:
        # DNS resolution + TCP connect; this is not a full proxy handshake.
        with socket.create_connection((host, port), timeout=TIMEOUT):
            return {"status":"tcp_reachable", "latency_ms":round((time.time()-start)*1000,1)}
    except Exception as e:
        return {"status":"unreachable", "latency_ms":None, "error":str(e)[:120]}

def clean_for_json(node):
    return {k:v for k,v in node.items() if not k.startswith("_") and k not in ("_check","_key")}

def to_clash(nodes):
    proxies = []
    for n in nodes:
        p = clean_for_json(n)
        # sing-box TLS object is not identical to Clash TLS boolean.
        if isinstance(p.get("tls"), dict):
            tls_obj = p.pop("tls")
            p["tls"] = bool(tls_obj.get("enabled", True))
            if tls_obj.get("server_name"):
                p["servername"] = tls_obj["server_name"]
        proxies.append(p)
    return yaml.safe_dump({"mixed-port":7890,"allow-lan":False,"mode":"rule",
                           "log-level":"info","proxies":proxies,
                           "proxy-groups":[{"name":"AUTO","type":"select",
                                            "proxies":[p["name"] for p in proxies]}],
                           "rules":["MATCH,AUTO"]}, allow_unicode=True, sort_keys=False)

def to_singbox(nodes):
    outbounds = []
    for n in nodes:
        p = clean_for_json(n)
        p["tag"] = p.pop("name", "node")
        p.pop("alter_id", None) if p.get("type") != "vmess" else None
        # Avoid exporting Clash-only fields that sing-box rejects.
        for k in ("cipher","network","ws-opts","servername"):
            if k in p and p["type"] != "ss":
                if k == "servername":
                    p.setdefault("tls", {})["server_name"] = p.pop(k)
                elif k == "network":
                    p.pop(k, None)
                elif k == "ws-opts":
                    p.pop(k, None)
        if isinstance(p.get("tls"), bool):
            p["tls"] = {"enabled": p["tls"]}
        outbounds.append(p)
    outbounds.append({"type":"direct","tag":"direct"})
    return json.dumps({"outbounds":outbounds,"route":{"final":"direct"}}, ensure_ascii=False, indent=2)

def main():
    OUT.mkdir(exist_ok=True)
    sources = read_sources()
    all_nodes, errors = [], []
    with ThreadPoolExecutor(max_workers=min(12, max(1,len(sources)))) as ex:
        futures = [ex.submit(fetch_source, u) for u in sources]
        for f in as_completed(futures):
            url, body, err = f.result()
            if err:
                errors.append({"source":url,"error":err})
                continue
            parsed = parse_feed(body, url)
            all_nodes.extend(parsed)

    unique = {}
    for n in all_nodes:
        unique.setdefault(node_key(n), n)
    nodes = list(unique.values())

    # Limit active checks to avoid overloading public endpoints.
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futures = {ex.submit(check_endpoint,n): n for n in nodes}
        for f in as_completed(futures):
            n = futures[f]
            try:
                n["_check"] = f.result()
            except Exception as e:
                n["_check"] = {"status":"unreachable","latency_ms":None,"error":str(e)[:120]}

    # Keep all syntactically parsed nodes in the raw output; separate TCP-reachable list.
    reachable = [n for n in nodes if n.get("_check",{}).get("status")=="tcp_reachable"]
    # Export only reachable nodes to client files; keep raw inventory in CSV/JSON.
    (OUT/"clash.yaml").write_text(to_clash(reachable), encoding="utf-8")
    (OUT/"sing-box.json").write_text(to_singbox(reachable), encoding="utf-8")
    v2ray_lines = [n["_raw_uri"] for n in reachable if n.get("_raw_uri")]
    raw = "\n".join(v2ray_lines).encode()
    (OUT/"v2ray.txt").write_text(base64.b64encode(raw).decode() if raw else "", encoding="utf-8")

    import csv
    with (OUT/"nodes.csv").open("w", newline="", encoding="utf-8-sig") as fp:
        writer = csv.DictWriter(fp, fieldnames=["name","type","server","server_port","status","latency_ms","source"])
        writer.writeheader()
        for n in nodes:
            c=n.get("_check",{})
            writer.writerow({"name":n.get("name"),"type":n.get("type"),"server":n.get("server"),
                             "server_port":n.get("server_port"),"status":c.get("status"),
                             "latency_ms":c.get("latency_ms"),"source":n.get("_source")})
    summary = {"sources":len(sources),"parsed_unique_nodes":len(nodes),
               "tcp_reachable":len(reachable),"failed_sources":errors,
               "note":"TCP reachability is not a full protocol handshake or guarantee of proxy usability.",
               "updated_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    (OUT/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__ == "__main__":
    main()
