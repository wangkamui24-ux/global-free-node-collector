# Global Public Node Collector

一个用于整理**公开且允许自动访问**的代理订阅源的 GitHub Actions 示例项目。

## 能做什么

- 从 `sources/sources.txt` 中读取公开 HTTP(S) 订阅源。
- 解析 Clash YAML、sing-box JSON、Base64 包装的 URI 订阅，以及常见 `ss://`、`vmess://`、`vless://`、`trojan://`、`hysteria2://`、`tuic://` URI。
- 去重，检查 DNS/TCP 可达性和 TCP 建连延迟。
- 输出 `output/clash.yaml`、`output/sing-box.json`、`output/v2ray.txt`、`output/nodes.csv`、`output/summary.json`。
- GitHub Actions 每 6 小时运行一次，也可手动运行。

## 手机部署

1. 在 GitHub 新建一个**Private** 仓库，例如 `global-free-node-collector`。
2. 下载并解压本项目 ZIP。
3. 在手机浏览器打开仓库，选择 **Add file → Upload files**，上传解压后的所有文件和文件夹（需保留 `.github/workflows/update.yml` 路径）。
4. 进入 **Settings → Actions → General → Workflow permissions**，选择 **Read and write permissions** 并保存。
5. 打开 **Actions**，启用工作流；进入 **Update public proxy feeds**，点击 **Run workflow**。
6. 后续每 6 小时自动执行。GitHub 定时任务可能延迟，不保证准点。

## 添加数据源

编辑 `sources/sources.txt`，每行添加一个公开订阅 URL。不要把私人订阅、账号密码或带个人令牌的 URL 放进公开仓库。建议仓库设为 Private。

## 获取订阅链接

运行成功后，打开仓库 `output/`：
- Clash：`output/clash.yaml`
- Sing-box：`output/sing-box.json`
- V2Ray：`output/v2ray.txt`

在文件页面点击 **Raw** 复制地址，填入客户端订阅管理。

注意：`v2ray.txt` 是从 URI 类型来源中保留原始分享链接后生成的 Base64 订阅。由 Clash YAML 或 sing-box JSON 解析出的节点不会被猜测转换成 URI，因此可能不包含这些节点。

## 检测能力边界

本项目的检测是 DNS 解析 + TCP 连接测试，不会完成各代理协议握手，也不测试真实下载速度。TCP 可达不等于代理一定可用；TCP 不可达也可能是临时网络问题。建议在自己的客户端再做实际连接验证。

## 重要限制

- 仅添加你有权访问且允许自动抓取的公开资源；遵守来源网站条款和当地法律。
- 不抓取私人群组、登录后内容、付费订阅或访问控制内容。
- 不要使用不可信免费节点处理银行、支付、密码或敏感通信。
- 运行时会对订阅内公布的主机和端口发起 TCP 检查；请只使用可信来源，避免恶意地址。
- 公开仓库会暴露采集结果和来源；建议仓库设为 Private。
- 输出转换只保留本程序支持的字段。某些协议高级参数可能需要手动检查。
